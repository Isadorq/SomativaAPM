class Dish {
  final String id;
  final String name;
  final String description;
  final double price;
  final String image;

  Dish({
    required this.id,
    required this.name,
    required this.description,
    required this.price,
    required this.image,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'description': description,
        'price': price,
        'image': image,
      };

  factory Dish.fromMap(Map<String, dynamic> map) => Dish(
        id: map['id'],
        name: map['name'],
        description: map['description'],
        price: map['price'],
        image: map['image'],
      );

  @override
  bool operator ==(other) => other is Dish && other.id == id;

  @override
  int get hashCode => id.hashCode;
}
