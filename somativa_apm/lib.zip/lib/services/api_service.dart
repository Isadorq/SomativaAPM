// lib/services/api_service.dart

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart'; 

class ApiService {
  
  // 🎯 SUBSTITUA ESTE ENDEREÇO PELO IP REAL DA SUA MÁQUINA!
  static const String _djangoBaseUrl = 'http://10.168.0.45:8000/api/'; 
  
  Future<bool> login({required String email, required String password}) async {
    // ... lógica de login
    try {
      final response = await http.post(
        Uri.parse('${_djangoBaseUrl}login/'), 
        // ...
      );
      return response.statusCode == 200;
    } catch (e) { /* ... */ return false; }
  }

  Future<bool> register({required String name, required String email, required String password}) async {
    // ... lógica de cadastro
    try {
      final response = await http.post(
        Uri.parse('${_djangoBaseUrl}register/'),
        // ...
      );
      return response.statusCode == 201; 
    } catch (e) { /* ... */ return false; }
  }

  Future<Map<String, dynamic>> fetchAddressByCep(String cep) async {
    final cleanCep = cep.replaceAll(RegExp(r'[^0-9]'), ''); 
    
    // Verifica se o CEP tem 8 dígitos
    if (cleanCep.length != 8) {
      // Lança uma exceção se o CEP for inválido
      throw Exception('CEP inválido. Deve conter 8 dígitos.');
    }
    
    // Faz a requisição HTTP GET para a API Via CEP
    final response = await http.get(
      Uri.parse('https://viacep.com.br/ws/$cleanCep/json/'),
    );

    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      
      // Verifica se a API retornou erro (CEP não encontrado)
      if (data.containsKey('erro') && data['erro'] == true) {
        throw Exception('CEP não encontrado. Verifique se o número está correto.');
      }
      // Retorna os dados do endereço
      return data;
    } else {
      // Lança uma exceção para erros de servidor (status code diferente de 200)
      throw Exception('Falha ao buscar CEP. Status: ${response.statusCode}');
    }
  }
}