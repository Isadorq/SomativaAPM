// lib/ui/widgets/dish_card.dart

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:somativa_apm/model/dish.dart';
import 'package:somativa_apm/restaurant/bag_provider.dart'; // Ajuste o caminho se necessário
import 'package:somativa_apm/ui/core/app_colors.dart';
import 'package:intl/intl.dart'; // Necessita do 'flutter pub add intl'

class DishCard extends StatelessWidget {
  final Dish dish;
  
  const DishCard({super.key, required this.dish});

  @override
  Widget build(BuildContext context) {
    // Acessa o provedor do carrinho sem reconstruir o widget (listen: false)
    final bagProvider = Provider.of<BagProvider>(context, listen: false);
    
    // Formato de moeda R$
    final currencyFormat = NumberFormat.currency(locale: 'pt_BR', symbol: 'R\$');

    return Card(
      elevation: 4,
      margin: const EdgeInsets.only(bottom: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Imagem do Prato
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(
                dish.imageUrl,
                width: 80,
                height: 80,
                fit: BoxFit.cover,
                // Placeholder/fallback em caso de erro no carregamento da imagem
                errorBuilder: (context, error, stackTrace) => Container(
                  width: 80,
                  height: 80,
                  color: Colors.grey[300],
                  child: const Icon(Icons.fastfood_outlined, color: Colors.grey),
                ),
              ),
            ),
            const SizedBox(width: 12),
            
            // Detalhes do Prato (Nome, Descrição, Preço)
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    dish.name,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    dish.description,
                    style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 8),
                  
                  // Preço Formatado
                  Text(
                    currencyFormat.format(dish.price),
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                      color: AppColors.primary,
                    ),
                  ),
                ],
              ),
            ),
            
            // Botão Adicionar ao Carrinho
            Align(
              alignment: Alignment.topRight,
              child: IconButton(
                icon: const Icon(Icons.add_circle, color: AppColors.secondary, size: 32),
                onPressed: () {
                  // Ação: Adiciona o prato ao BagProvider
                  bagProvider.addItem(dish);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('${dish.name} adicionado ao carrinho!'),
                      duration: const Duration(seconds: 1),
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}