// lib/ui/widgets/checkout/checkoutscreen.dart (MODIFICADO)

import 'package:somativa_apm/model/dish.dart';
import 'package:somativa_apm/ui/core/app_colors.dart';
import 'package:somativa_apm/ui/widgets/bag_provider.dart';
import 'package:somativa_apm/services/api_service.dart'; // Importa o serviço de API/CEP
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class Checkoutscreen extends StatefulWidget {
  const Checkoutscreen({super.key});

  @override
  State<Checkoutscreen> createState() => _CheckoutscreenState();
}

class _CheckoutscreenState extends State<Checkoutscreen> {
  final TextEditingController _cepController = TextEditingController();
  final ApiService _apiService = ApiService();
  String _address = 'Endereço não definido. Busque o CEP.';
  bool _isCepLoading = false;
  double _freightValue = 0.0; // Valor inicial do frete
  static const double standardFreight = 10.00; // Frete padrão R$ 10.00
  static const double freeFreightThreshold = 100.00; // Limite R$ 100.00

  // Função para buscar o CEP e calcular o frete (Requisitos D e E)
  Future<void> _searchCep(double subtotal) async {
    final cep = _cepController.text;
    if (cep.replaceAll(RegExp(r'[^0-9]'), '').length < 8) {
      setState(() {
        _address = 'CEP inválido.';
        _freightValue = 0.0;
      });
      return;
    }

    setState(() {
      _isCepLoading = true;
      _address = 'Buscando endereço...';
    });

    try {
      final addressData = await _apiService.fetchAddressByCep(cep);
      
      // Monta o endereço simples
      _address = '${addressData['logradouro']}, ${addressData['bairro']} - ${addressData['localidade']}/${addressData['uf']}';
      
      // Lógica de Frete (Requisito D): Se o subtotal for maior que R$ 100,00, frete é R$ 0,00
      _freightValue = (subtotal > freeFreightThreshold) ? 0.0 : standardFreight;

    } catch (e) {
      _address = 'CEP não encontrado ou erro na busca.';
      _freightValue = 0.0; 
    } finally {
      setState(() {
        _isCepLoading = false;
      });
    }
  }

  @override
  void dispose() {
    _cepController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    BagProvider bagProvider = Provider.of<BagProvider>(context);

    // 1. Calcula o subtotal (valor dos pratos)
    double subtotal = 0;
    bagProvider.getMapByAmount().forEach((dish, amount) {
      // O preço deve ser dividido por 100 se estiver em centavos
      subtotal += (dish.price / 100) * amount;
    });

    double finalTotal = subtotal + _freightValue; // Valor final (subtotal + frete)


    return Scaffold(
      appBar: AppBar(
        title: const Text('Sacola'),
        actions: [
          TextButton(
            onPressed: () {
              bagProvider.clearBag();
              setState(() { // Limpa o frete/endereço ao limpar o carrinho
                _freightValue = 0.0;
                _address = 'Endereço não definido. Busque o CEP.';
              });
            },
            child: const Text('Limpar'),
          )
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('Pedidos', textAlign: TextAlign.center, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            
            // Lista de Itens (mantida)
            Column(
              children: List.generate(
                bagProvider.getMapByAmount().keys.length,
                (index) {
                  Dish dish = bagProvider.getMapByAmount().keys.toList()[index];
                  int amount = bagProvider.getMapByAmount()[dish]!;
                  return ListTile(
                    leading: Image.asset('assets/dishes/default.png', width: 48, height: 48,),
                    title: Text('${dish.name} x $amount'),
                    subtitle: Text('R\$${((dish.price / 100) * amount).toStringAsFixed(2)}'),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(onPressed: () => bagProvider.removeDish(dish), icon: const Icon(Icons.remove_circle_outline)),
                        IconButton(onPressed: () => bagProvider.addAllDishes([dish]), icon: const Icon(Icons.add_circle_outline)),
                      ],
                    ),
                  );
                },
              ),
            ),
            
            const SizedBox(height: 32),
            const Divider(color: AppColors.lightBackgroundColor),
            
            const Text('Local de Entrega', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),

            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _cepController,
                    keyboardType: TextInputType.number,
                    maxLength: 8,
                    decoration: const InputDecoration(labelText: 'CEP', hintText: 'Digite o CEP', counterText: "", isDense: true),
                  ),
                ),
                const SizedBox(width: 8),
                SizedBox(
                  height: 40,
                  child: ElevatedButton(
                    onPressed: _isCepLoading ? null : () => _searchCep(subtotal),
                    child: _isCepLoading
                        ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2))
                        : const Text('Buscar'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            
            // Exibição do Endereço
            Text('Endereço: $_address', style: const TextStyle(fontSize: 14, color: Colors.white70)),
            const SizedBox(height: 32),

            // =======================================================
            // EXIBIÇÃO DOS TOTAIS
            // =======================================================

            // Subtotal
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Subtotal:', style: TextStyle(fontSize: 16)),
                Text('R\$${subtotal.toStringAsFixed(2)}', style: const TextStyle(fontSize: 16)),
              ],
            ),
            const SizedBox(height: 8),

            // Frete (Requisito D)
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Frete:', style: TextStyle(fontSize: 16)),
                Text(
                  _freightValue == 0.0 && subtotal >= freeFreightThreshold && _address != 'Endereço não definido. Busque o CEP.'
                    ? 'GRÁTIS' // Exibe "GRÁTIS" se a regra de R$ 100 for cumprida e o CEP for buscado
                    : 'R\$${_freightValue.toStringAsFixed(2)}', 
                  style: TextStyle(fontSize: 16, color: _freightValue == 0.0 ? Colors.green : Colors.white)
                ),
              ],
            ),
            const SizedBox(height: 16),
            const Divider(color: AppColors.mainColor),

            // Total Final
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Total Final:', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                Text('R\$${finalTotal.toStringAsFixed(2)}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ],
            ),
            
            const SizedBox(height: 32),
            
            // [Outras informações de pagamento] - Mantenha o código original aqui.
            // Para simplificar, vou remover o código do cartão de crédito que estava no snippet
            // e focar apenas na finalização do pedido.
            
            // Botão Pedir
            ElevatedButton(
              onPressed: subtotal > 0 && _freightValue >= 0.0 // Desabilita se vazio ou frete não calculado
                  ? () {
                      bagProvider.clearBag();
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Pedido realizado!')));
                      // Volta para a home
                      Navigator.popUntil(context, (route) => route.isFirst);
                    }
                  : null, 
              child: const Text('Pedir', style: TextStyle(fontSize: 18)),
            )
          ],
        ),
      ),
    );
  }
}