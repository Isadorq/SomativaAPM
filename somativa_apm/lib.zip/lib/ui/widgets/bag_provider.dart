// lib/ui/widgets/bag_provider.dart

import 'package:somativa_apm/model/dish.dart'; // Import corrigido
import 'package:flutter/material.dart';

class BagProvider  extends ChangeNotifier{
  List<Dish>dishesOnBag=[]; // cria uma lista vazia para os itens na sacola

// metodo para adicionar itens ao carrinho
  addAllDishes(List<Dish>dishes){
    dishesOnBag.addAll(dishes);
    notifyListeners();
  }

  removeDish(Dish dish){
    dishesOnBag.remove(dish);
    notifyListeners();
  }

  @override
  String toString(){
    return 'BagProvider(dishesOnBag: $dishesOnBag)';
  }

  clearBag() async {
    dishesOnBag.clear();
    notifyListeners();
    // Adicionei um pequeno delay para limpar o frete no Checkout
    await Future.delayed(const Duration(milliseconds: 100));
  }

  // Retorna um mapa (prato, quantidade)
  Map<Dish,int> getMapByAmount(){
    Map<Dish,int>mapResult ={};
    for(Dish dish in dishesOnBag){
      // Se o prato não está no mapa, adiciona com 1
      if(mapResult[dish]==null){
        mapResult[dish]=1;
      }else{
        // Se já está, incrementa a quantidade
        mapResult[dish]=mapResult[dish]!+1;
      }
    }
    return mapResult;
  }

}