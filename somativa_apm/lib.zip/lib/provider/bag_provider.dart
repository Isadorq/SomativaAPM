import 'package:flutter/material.dart';
import '/model/dish.dart';

class BagProvider extends ChangeNotifier {
  final Map<Dish, int> _items = {};

  Map<Dish, int> get items => _items;

  void add(Dish dish) {
    _items.update(dish, (value) => value + 1, ifAbsent: () => 1);
    notifyListeners();
  }

  void remove(Dish dish) {
    if (_items.containsKey(dish)) {
      if (_items[dish]! > 1) {
        _items[dish] = _items[dish]! - 1;
      } else {
        _items.remove(dish);
      }
      notifyListeners();
    }
  }

  void clear() {
    _items.clear();
    notifyListeners();
  }

  double get total =>
      _items.entries.fold(0, (sum, e) => sum + e.key.price * e.value);
}
