import '../model/dish.dart';

List<Dish> dishes = [
  Dish(
    id: '1',
    name: 'Pizza Calabresa',
    description: 'Molho, queijo, calabresa e cebola.',
    price: 38.90,
    image: 'assets/images/pizza1.png',
  ),
  Dish(
    id: '2',
    name: 'X-Burguer',
    description: 'Pão, carne, queijo e maionese.',
    price: 22.50,
    image: 'assets/images/burger1.png',
  ),
];
