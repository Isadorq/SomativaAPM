// lib/screens/home_screen.dart

import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mange Eats - Cardápio'),
        automaticallyImplyLeading: false, // Remove a seta de voltar após o login
      ),
      body: const Center(
        child: Text('Bem-vindo(a)! Escolha seu pedido.'),
      ),
    );
  }
}